export default function App() {
  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1>OUTRIGHT UI React</h1>
      <p>Esta es una versión base. Aquí se incluirá la tabla dinámica con edición, validaciones y bloqueo de fórmulas.</p>
    </div>
  );
}
